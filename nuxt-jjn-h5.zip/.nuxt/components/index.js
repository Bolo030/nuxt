export { default as MyComponentsInstall } from '../..\\components\\myComponentsInstall.js'
export { default as CustomStoreFilter } from '../..\\components\\custom-store-filter\\custom-store-filter.vue'
export { default as CustomStoreFilterData } from '../..\\components\\custom-store-filter\\data.js'
export { default as CommonCard } from '../..\\components\\common\\card.vue'
export { default as CommonCustomDialog } from '../..\\components\\common\\custom-dialog.vue'
export { default as CommonCustomTabbar } from '../..\\components\\common\\custom-tabbar.vue'
export { default as CommonLogin } from '../..\\components\\common\\login.vue'
export { default as CommonStoreList } from '../..\\components\\common\\store-list.vue'
export { default as StoreInfoCustomerService } from '../..\\components\\store-info\\customer-service.vue'
export { default as CustomStoreFilterSide } from '../..\\components\\custom-store-filter\\components\\FilterSide.vue'

export const LazyMyComponentsInstall = import('../..\\components\\myComponentsInstall.js' /* webpackChunkName: "components/my-components-install" */).then(c => wrapFunctional(c.default || c))
export const LazyCustomStoreFilter = import('../..\\components\\custom-store-filter\\custom-store-filter.vue' /* webpackChunkName: "components/custom-store-filter" */).then(c => wrapFunctional(c.default || c))
export const LazyCustomStoreFilterData = import('../..\\components\\custom-store-filter\\data.js' /* webpackChunkName: "components/custom-store-filter-data" */).then(c => wrapFunctional(c.default || c))
export const LazyCommonCard = import('../..\\components\\common\\card.vue' /* webpackChunkName: "components/common-card" */).then(c => wrapFunctional(c.default || c))
export const LazyCommonCustomDialog = import('../..\\components\\common\\custom-dialog.vue' /* webpackChunkName: "components/common-custom-dialog" */).then(c => wrapFunctional(c.default || c))
export const LazyCommonCustomTabbar = import('../..\\components\\common\\custom-tabbar.vue' /* webpackChunkName: "components/common-custom-tabbar" */).then(c => wrapFunctional(c.default || c))
export const LazyCommonLogin = import('../..\\components\\common\\login.vue' /* webpackChunkName: "components/common-login" */).then(c => wrapFunctional(c.default || c))
export const LazyCommonStoreList = import('../..\\components\\common\\store-list.vue' /* webpackChunkName: "components/common-store-list" */).then(c => wrapFunctional(c.default || c))
export const LazyStoreInfoCustomerService = import('../..\\components\\store-info\\customer-service.vue' /* webpackChunkName: "components/store-info-customer-service" */).then(c => wrapFunctional(c.default || c))
export const LazyCustomStoreFilterSide = import('../..\\components\\custom-store-filter\\components\\FilterSide.vue' /* webpackChunkName: "components/custom-store-filter-side" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
export function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
