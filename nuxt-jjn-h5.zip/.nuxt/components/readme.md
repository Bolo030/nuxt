# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<MyComponentsInstall>` | `<my-components-install>` (components/myComponentsInstall.js)
- `<CommonCard>` | `<common-card>` (components/common/card.vue)
- `<CommonCustomDialog>` | `<common-custom-dialog>` (components/common/custom-dialog.vue)
- `<CommonCustomTabbar>` | `<common-custom-tabbar>` (components/common/custom-tabbar.vue)
- `<CommonStoreList>` | `<common-store-list>` (components/common/store-list.vue)
- `<CustomStoreFilter>` | `<custom-store-filter>` (components/custom-store-filter/custom-store-filter.vue)
- `<CustomStoreFilterData>` | `<custom-store-filter-data>` (components/custom-store-filter/data.js)
- `<StoreInfoCustomerService>` | `<store-info-customer-service>` (components/store-info/customer-service.vue)
- `<CustomStoreFilterSide>` | `<custom-store-filter-side>` (components/custom-store-filter/components/FilterSide.vue)
