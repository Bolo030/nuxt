import Vue from 'vue'
import { wrapFunctional } from './index'

const components = {
  MyComponentsInstall: () => import('../..\\components\\myComponentsInstall.js' /* webpackChunkName: "components/my-components-install" */).then(c => wrapFunctional(c.default || c)),
  CommonCard: () => import('../..\\components\\common\\card.vue' /* webpackChunkName: "components/common-card" */).then(c => wrapFunctional(c.default || c)),
  CommonCustomDialog: () => import('../..\\components\\common\\custom-dialog.vue' /* webpackChunkName: "components/common-custom-dialog" */).then(c => wrapFunctional(c.default || c)),
  CommonCustomTabbar: () => import('../..\\components\\common\\custom-tabbar.vue' /* webpackChunkName: "components/common-custom-tabbar" */).then(c => wrapFunctional(c.default || c)),
  CommonLogin: () => import('../..\\components\\common\\login.vue' /* webpackChunkName: "components/common-login" */).then(c => wrapFunctional(c.default || c)),
  CommonStoreList: () => import('../..\\components\\common\\store-list.vue' /* webpackChunkName: "components/common-store-list" */).then(c => wrapFunctional(c.default || c)),
  CustomStoreFilter: () => import('../..\\components\\custom-store-filter\\custom-store-filter.vue' /* webpackChunkName: "components/custom-store-filter" */).then(c => wrapFunctional(c.default || c)),
  CustomStoreFilterData: () => import('../..\\components\\custom-store-filter\\data.js' /* webpackChunkName: "components/custom-store-filter-data" */).then(c => wrapFunctional(c.default || c)),
  StoreInfoCustomerService: () => import('../..\\components\\store-info\\customer-service.vue' /* webpackChunkName: "components/store-info-customer-service" */).then(c => wrapFunctional(c.default || c)),
  CustomStoreFilterSide: () => import('../..\\components\\custom-store-filter\\components\\FilterSide.vue' /* webpackChunkName: "components/custom-store-filter-side" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
