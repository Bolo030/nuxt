import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _2dba14ba = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages/about" */))
const _3d69d3f6 = () => interopDefault(import('..\\pages\\article\\index.vue' /* webpackChunkName: "pages/article/index" */))
const _3a7a2385 = () => interopDefault(import('..\\pages\\assets\\index.vue' /* webpackChunkName: "pages/assets/index" */))
const _6608bf16 = () => interopDefault(import('..\\pages\\contract\\index.vue' /* webpackChunkName: "pages/contract/index" */))
const _05d83b6e = () => interopDefault(import('..\\pages\\enter.vue' /* webpackChunkName: "pages/enter" */))
const _812f224a = () => interopDefault(import('..\\pages\\forget\\index.vue' /* webpackChunkName: "pages/forget/index" */))
const _696dc423 = () => interopDefault(import('..\\pages\\login\\index.vue' /* webpackChunkName: "pages/login/index" */))
const _e81c4f80 = () => interopDefault(import('..\\pages\\search\\index.vue' /* webpackChunkName: "pages/search/index" */))
const _fc02c0aa = () => interopDefault(import('..\\pages\\store\\index.vue' /* webpackChunkName: "pages/store/index" */))
const _8e41d486 = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _47b97d2d = () => interopDefault(import('..\\pages\\zur.vue' /* webpackChunkName: "pages/zur" */))
const _9d2e2e18 = () => interopDefault(import('..\\pages\\activity\\rulesDetails.vue' /* webpackChunkName: "pages/activity/rulesDetails" */))
const _0823ba5d = () => interopDefault(import('..\\pages\\article\\detail.vue' /* webpackChunkName: "pages/article/detail" */))
const _4dede725 = () => interopDefault(import('..\\pages\\article\\interview.vue' /* webpackChunkName: "pages/article/interview" */))
const _3988977d = () => interopDefault(import('..\\pages\\assets\\frozen.vue' /* webpackChunkName: "pages/assets/frozen" */))
const _b04c7ada = () => interopDefault(import('..\\pages\\assets\\rh.vue' /* webpackChunkName: "pages/assets/rh" */))
const _afbf8fd0 = () => interopDefault(import('..\\pages\\assets\\rm.vue' /* webpackChunkName: "pages/assets/rm" */))
const _aea5b9bc = () => interopDefault(import('..\\pages\\assets\\rw.vue' /* webpackChunkName: "pages/assets/rw" */))
const _27c75f76 = () => interopDefault(import('..\\pages\\assets\\success.vue' /* webpackChunkName: "pages/assets/success" */))
const _9facc0ac = () => interopDefault(import('..\\pages\\assets\\wd.vue' /* webpackChunkName: "pages/assets/wd" */))
const _79c618bd = () => interopDefault(import('..\\pages\\contract\\lookContract.vue' /* webpackChunkName: "pages/contract/lookContract" */))
const _9c5ca14c = () => interopDefault(import('..\\pages\\login\\visitorsOrder.vue' /* webpackChunkName: "pages/login/visitorsOrder" */))
const _1a9ff113 = () => interopDefault(import('..\\pages\\settlement\\payment.vue' /* webpackChunkName: "pages/settlement/payment" */))
const _33257220 = () => interopDefault(import('..\\pages\\settlement\\paymentSuccess.vue' /* webpackChunkName: "pages/settlement/paymentSuccess" */))
const _ac090554 = () => interopDefault(import('..\\pages\\tool\\assess.vue' /* webpackChunkName: "pages/tool/assess" */))
const _c290b426 = () => interopDefault(import('..\\pages\\tool\\buyStore.vue' /* webpackChunkName: "pages/tool/buyStore" */))
const _2e871eb6 = () => interopDefault(import('..\\pages\\user\\aboutUs.vue' /* webpackChunkName: "pages/user/aboutUs" */))
const _5fa17955 = () => interopDefault(import('..\\pages\\user\\auth\\index.vue' /* webpackChunkName: "pages/user/auth/index" */))
const _d7a8277e = () => interopDefault(import('..\\pages\\user\\bank\\index.vue' /* webpackChunkName: "pages/user/bank/index" */))
const _5ac7d955 = () => interopDefault(import('..\\pages\\user\\collect.vue' /* webpackChunkName: "pages/user/collect" */))
const _bcebc264 = () => interopDefault(import('..\\pages\\user\\complain.vue' /* webpackChunkName: "pages/user/complain" */))
const _5d717ecb = () => interopDefault(import('..\\pages\\user\\coupon.vue' /* webpackChunkName: "pages/user/coupon" */))
const _75a877ef = () => interopDefault(import('..\\pages\\user\\editPhone.vue' /* webpackChunkName: "pages/user/editPhone" */))
const _2292e693 = () => interopDefault(import('..\\pages\\user\\info.vue' /* webpackChunkName: "pages/user/info" */))
const _0ffc8bde = () => interopDefault(import('..\\pages\\user\\integral.vue' /* webpackChunkName: "pages/user/integral" */))
const _8f727c9c = () => interopDefault(import('..\\pages\\user\\message.vue' /* webpackChunkName: "pages/user/message" */))
const _c74ff836 = () => interopDefault(import('..\\pages\\user\\my-store.vue' /* webpackChunkName: "pages/user/my-store" */))
const _74a9bb13 = () => interopDefault(import('..\\pages\\user\\newPhone.vue' /* webpackChunkName: "pages/user/newPhone" */))
const _5cac538e = () => interopDefault(import('..\\pages\\user\\order.vue' /* webpackChunkName: "pages/user/order" */))
const _09d01c36 = () => interopDefault(import('..\\pages\\user\\seting.vue' /* webpackChunkName: "pages/user/seting" */))
const _dd45aaa2 = () => interopDefault(import('..\\pages\\user\\suggest.vue' /* webpackChunkName: "pages/user/suggest" */))
const _3b8fe5ea = () => interopDefault(import('..\\pages\\user\\userAgreement.vue' /* webpackChunkName: "pages/user/userAgreement" */))
const _f5824aee = () => interopDefault(import('..\\pages\\user\\auth\\bank.vue' /* webpackChunkName: "pages/user/auth/bank" */))
const _526ddff1 = () => interopDefault(import('..\\pages\\user\\auth\\phone.vue' /* webpackChunkName: "pages/user/auth/phone" */))
const _bf1efd74 = () => interopDefault(import('..\\pages\\user\\auth\\success.vue' /* webpackChunkName: "pages/user/auth/success" */))
const _f8c57848 = () => interopDefault(import('..\\pages\\user\\bank\\addBankCard.vue' /* webpackChunkName: "pages/user/bank/addBankCard" */))
const _0fdba3f2 = () => interopDefault(import('..\\pages\\user\\bank\\openBank.vue' /* webpackChunkName: "pages/user/bank/openBank" */))
const _41a87df8 = () => interopDefault(import('..\\pages\\user\\order-info\\buy.vue' /* webpackChunkName: "pages/user/order-info/buy" */))
const _64dba348 = () => interopDefault(import('..\\pages\\bargain\\_key.vue' /* webpackChunkName: "pages/bargain/_key" */))
const _1eae3cba = () => interopDefault(import('..\\pages\\order-success\\_key.vue' /* webpackChunkName: "pages/order-success/_key" */))
const _23e66ce3 = () => interopDefault(import('..\\pages\\settlement\\_key.vue' /* webpackChunkName: "pages/settlement/_key" */))
const _54657fd0 = () => interopDefault(import('..\\pages\\si\\_key.vue' /* webpackChunkName: "pages/si/_key" */))
const _08dad068 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _2dba14ba,
    name: "about"
  }, {
    path: "/article",
    component: _3d69d3f6,
    name: "article"
  }, {
    path: "/assets",
    component: _3a7a2385,
    name: "assets"
  }, {
    path: "/contract",
    component: _6608bf16,
    name: "contract"
  }, {
    path: "/enter",
    component: _05d83b6e,
    name: "enter"
  }, {
    path: "/forget",
    component: _812f224a,
    name: "forget"
  }, {
    path: "/login",
    component: _696dc423,
    name: "login"
  }, {
    path: "/search",
    component: _e81c4f80,
    name: "search"
  }, {
    path: "/store",
    component: _fc02c0aa,
    name: "store"
  }, {
    path: "/user",
    component: _8e41d486,
    name: "user"
  }, {
    path: "/zur",
    component: _47b97d2d,
    name: "zur"
  }, {
    path: "/activity/rulesDetails",
    component: _9d2e2e18,
    name: "activity-rulesDetails"
  }, {
    path: "/article/detail",
    component: _0823ba5d,
    name: "article-detail"
  }, {
    path: "/article/interview",
    component: _4dede725,
    name: "article-interview"
  }, {
    path: "/assets/frozen",
    component: _3988977d,
    name: "assets-frozen"
  }, {
    path: "/assets/rh",
    component: _b04c7ada,
    name: "assets-rh"
  }, {
    path: "/assets/rm",
    component: _afbf8fd0,
    name: "assets-rm"
  }, {
    path: "/assets/rw",
    component: _aea5b9bc,
    name: "assets-rw"
  }, {
    path: "/assets/success",
    component: _27c75f76,
    name: "assets-success"
  }, {
    path: "/assets/wd",
    component: _9facc0ac,
    name: "assets-wd"
  }, {
    path: "/contract/lookContract",
    component: _79c618bd,
    name: "contract-lookContract"
  }, {
    path: "/login/visitorsOrder",
    component: _9c5ca14c,
    name: "login-visitorsOrder"
  }, {
    path: "/settlement/payment",
    component: _1a9ff113,
    name: "settlement-payment"
  }, {
    path: "/settlement/paymentSuccess",
    component: _33257220,
    name: "settlement-paymentSuccess"
  }, {
    path: "/tool/assess",
    component: _ac090554,
    name: "tool-assess"
  }, {
    path: "/tool/buyStore",
    component: _c290b426,
    name: "tool-buyStore"
  }, {
    path: "/user/aboutUs",
    component: _2e871eb6,
    name: "user-aboutUs"
  }, {
    path: "/user/auth",
    component: _5fa17955,
    name: "user-auth"
  }, {
    path: "/user/bank",
    component: _d7a8277e,
    name: "user-bank"
  }, {
    path: "/user/collect",
    component: _5ac7d955,
    name: "user-collect"
  }, {
    path: "/user/complain",
    component: _bcebc264,
    name: "user-complain"
  }, {
    path: "/user/coupon",
    component: _5d717ecb,
    name: "user-coupon"
  }, {
    path: "/user/editPhone",
    component: _75a877ef,
    name: "user-editPhone"
  }, {
    path: "/user/info",
    component: _2292e693,
    name: "user-info"
  }, {
    path: "/user/integral",
    component: _0ffc8bde,
    name: "user-integral"
  }, {
    path: "/user/message",
    component: _8f727c9c,
    name: "user-message"
  }, {
    path: "/user/my-store",
    component: _c74ff836,
    name: "user-my-store"
  }, {
    path: "/user/newPhone",
    component: _74a9bb13,
    name: "user-newPhone"
  }, {
    path: "/user/order",
    component: _5cac538e,
    name: "user-order"
  }, {
    path: "/user/seting",
    component: _09d01c36,
    name: "user-seting"
  }, {
    path: "/user/suggest",
    component: _dd45aaa2,
    name: "user-suggest"
  }, {
    path: "/user/userAgreement",
    component: _3b8fe5ea,
    name: "user-userAgreement"
  }, {
    path: "/user/auth/bank",
    component: _f5824aee,
    name: "user-auth-bank"
  }, {
    path: "/user/auth/phone",
    component: _526ddff1,
    name: "user-auth-phone"
  }, {
    path: "/user/auth/success",
    component: _bf1efd74,
    name: "user-auth-success"
  }, {
    path: "/user/bank/addBankCard",
    component: _f8c57848,
    name: "user-bank-addBankCard"
  }, {
    path: "/user/bank/openBank",
    component: _0fdba3f2,
    name: "user-bank-openBank"
  }, {
    path: "/user/order-info/buy",
    component: _41a87df8,
    name: "user-order-info-buy"
  }, {
    path: "/bargain/:key?",
    component: _64dba348,
    name: "bargain-key"
  }, {
    path: "/order-success/:key?",
    component: _1eae3cba,
    name: "order-success-key"
  }, {
    path: "/settlement/:key?",
    component: _23e66ce3,
    name: "settlement-key"
  }, {
    path: "/si/:key?",
    component: _54657fd0,
    name: "si-key"
  }, {
    path: "/",
    component: _08dad068,
    name: "index"
  }, {
    path: "/article/list-:id",
    component: _3d69d3f6,
    name: "article"
  }, {
    path: "/article/detail-:id",
    component: _0823ba5d,
    name: "detail"
  }, {
    path: "/article/interview-:id",
    component: _4dede725,
    name: "interview"
  }, {
    path: "/:store/:id?",
    component: _fc02c0aa,
    name: "store"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config.app && config.app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
