import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _964514d6 = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages/about" */))
const _7012dd12 = () => interopDefault(import('..\\pages\\assets\\index.vue' /* webpackChunkName: "pages/assets/index" */))
const _f3bd0ef0 = () => interopDefault(import('..\\pages\\contract\\index.vue' /* webpackChunkName: "pages/contract/index" */))
const _5cda8940 = () => interopDefault(import('..\\pages\\enter.vue' /* webpackChunkName: "pages/enter" */))
const _4ce4dccd = () => interopDefault(import('..\\pages\\forget\\index.vue' /* webpackChunkName: "pages/forget/index" */))
const _7eda601e = () => interopDefault(import('..\\pages\\login\\index.vue' /* webpackChunkName: "pages/login/index" */))
const _196e4632 = () => interopDefault(import('..\\pages\\search\\index.vue' /* webpackChunkName: "pages/search/index" */))
const _ebbb4fa2 = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _d8d15cc2 = () => interopDefault(import('..\\pages\\zur.vue' /* webpackChunkName: "pages/zur" */))
const _7bf7e97c = () => interopDefault(import('..\\pages\\activity\\rulesDetails.vue' /* webpackChunkName: "pages/activity/rulesDetails" */))
const _283c73cf = () => interopDefault(import('..\\pages\\article\\detail.vue' /* webpackChunkName: "pages/article/detail" */))
const _6b226073 = () => interopDefault(import('..\\pages\\article\\interview.vue' /* webpackChunkName: "pages/article/interview" */))
const _5b99e7cb = () => interopDefault(import('..\\pages\\assets\\frozen.vue' /* webpackChunkName: "pages/assets/frozen" */))
const _74cb69e1 = () => interopDefault(import('..\\pages\\assets\\rh.vue' /* webpackChunkName: "pages/assets/rh" */))
const _7511df66 = () => interopDefault(import('..\\pages\\assets\\rm.vue' /* webpackChunkName: "pages/assets/rm" */))
const _759eca70 = () => interopDefault(import('..\\pages\\assets\\rw.vue' /* webpackChunkName: "pages/assets/rw" */))
const _7d1b46f8 = () => interopDefault(import('..\\pages\\assets\\wd.vue' /* webpackChunkName: "pages/assets/wd" */))
const _5ec4beca = () => interopDefault(import('..\\pages\\assets\\wdSuccess.vue' /* webpackChunkName: "pages/assets/wdSuccess" */))
const _53cd0d28 = () => interopDefault(import('..\\pages\\login\\visitorsOrder.vue' /* webpackChunkName: "pages/login/visitorsOrder" */))
const _b80abcf6 = () => interopDefault(import('..\\pages\\settlement\\payment.vue' /* webpackChunkName: "pages/settlement/payment" */))
const _61aabd6e = () => interopDefault(import('..\\pages\\settlement\\paymentSuccess.vue' /* webpackChunkName: "pages/settlement/paymentSuccess" */))
const _01208924 = () => interopDefault(import('..\\pages\\tool\\assess.vue' /* webpackChunkName: "pages/tool/assess" */))
const _7e6e138a = () => interopDefault(import('..\\pages\\tool\\buyStore.vue' /* webpackChunkName: "pages/tool/buyStore" */))
const _87f8e6b0 = () => interopDefault(import('..\\pages\\user\\aboutUs.vue' /* webpackChunkName: "pages/user/aboutUs" */))
const _471cc372 = () => interopDefault(import('..\\pages\\user\\auth\\index.vue' /* webpackChunkName: "pages/user/auth/index" */))
const _10fc1133 = () => interopDefault(import('..\\pages\\user\\bank\\index.vue' /* webpackChunkName: "pages/user/bank/index" */))
const _2f777172 = () => interopDefault(import('..\\pages\\user\\collect.vue' /* webpackChunkName: "pages/user/collect" */))
const _78c921c8 = () => interopDefault(import('..\\pages\\user\\complain.vue' /* webpackChunkName: "pages/user/complain" */))
const _d47d9d3e = () => interopDefault(import('..\\pages\\user\\editPhone.vue' /* webpackChunkName: "pages/user/editPhone" */))
const _20f6e43e = () => interopDefault(import('..\\pages\\user\\info.vue' /* webpackChunkName: "pages/user/info" */))
const _45c32fa4 = () => interopDefault(import('..\\pages\\user\\message.vue' /* webpackChunkName: "pages/user/message" */))
const _832d579a = () => interopDefault(import('..\\pages\\user\\my-store.vue' /* webpackChunkName: "pages/user/my-store" */))
const _ba25ceaa = () => interopDefault(import('..\\pages\\user\\order.vue' /* webpackChunkName: "pages/user/order" */))
const _523cfdb3 = () => interopDefault(import('..\\pages\\user\\seting.vue' /* webpackChunkName: "pages/user/seting" */))
const _1ed998a1 = () => interopDefault(import('..\\pages\\user\\suggest.vue' /* webpackChunkName: "pages/user/suggest" */))
const _683d4f57 = () => interopDefault(import('..\\pages\\user\\auth\\bank.vue' /* webpackChunkName: "pages/user/auth/bank" */))
const _6183f63a = () => interopDefault(import('..\\pages\\user\\auth\\phone.vue' /* webpackChunkName: "pages/user/auth/phone" */))
const _29cb31b8 = () => interopDefault(import('..\\pages\\user\\auth\\success.vue' /* webpackChunkName: "pages/user/auth/success" */))
const _f3332964 = () => interopDefault(import('..\\pages\\user\\bank\\addBankCard.vue' /* webpackChunkName: "pages/user/bank/addBankCard" */))
const _cbe4e856 = () => interopDefault(import('..\\pages\\user\\bank\\openBank.vue' /* webpackChunkName: "pages/user/bank/openBank" */))
const _7c9c1cf6 = () => interopDefault(import('..\\pages\\user\\order-info\\buy.vue' /* webpackChunkName: "pages/user/order-info/buy" */))
const _4d4d67ac = () => interopDefault(import('..\\pages\\article\\_id.vue' /* webpackChunkName: "pages/article/_id" */))
const _1b4fdd8c = () => interopDefault(import('..\\pages\\bargain\\_key.vue' /* webpackChunkName: "pages/bargain/_key" */))
const _afee25a8 = () => interopDefault(import('..\\pages\\order-success\\_key.vue' /* webpackChunkName: "pages/order-success/_key" */))
const _06e4e1b1 = () => interopDefault(import('..\\pages\\settlement\\_key.vue' /* webpackChunkName: "pages/settlement/_key" */))
const _7094a29e = () => interopDefault(import('..\\pages\\si\\_key.vue' /* webpackChunkName: "pages/si/_key" */))
const _56d55f4c = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _3e079820 = () => interopDefault(import('..\\pages\\_store\\_id.vue' /* webpackChunkName: "pages/_store/_id" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _964514d6,
    name: "about"
  }, {
    path: "/assets",
    component: _7012dd12,
    name: "assets"
  }, {
    path: "/contract",
    component: _f3bd0ef0,
    name: "contract"
  }, {
    path: "/enter",
    component: _5cda8940,
    name: "enter"
  }, {
    path: "/forget",
    component: _4ce4dccd,
    name: "forget"
  }, {
    path: "/login",
    component: _7eda601e,
    name: "login"
  }, {
    path: "/search",
    component: _196e4632,
    name: "search"
  }, {
    path: "/user",
    component: _ebbb4fa2,
    name: "user"
  }, {
    path: "/zur",
    component: _d8d15cc2,
    name: "zur"
  }, {
    path: "/activity/rulesDetails",
    component: _7bf7e97c,
    name: "activity-rulesDetails"
  }, {
    path: "/article/detail",
    component: _283c73cf,
    name: "article-detail"
  }, {
    path: "/article/interview",
    component: _6b226073,
    name: "article-interview"
  }, {
    path: "/assets/frozen",
    component: _5b99e7cb,
    name: "assets-frozen"
  }, {
    path: "/assets/rh",
    component: _74cb69e1,
    name: "assets-rh"
  }, {
    path: "/assets/rm",
    component: _7511df66,
    name: "assets-rm"
  }, {
    path: "/assets/rw",
    component: _759eca70,
    name: "assets-rw"
  }, {
    path: "/assets/wd",
    component: _7d1b46f8,
    name: "assets-wd"
  }, {
    path: "/assets/wdSuccess",
    component: _5ec4beca,
    name: "assets-wdSuccess"
  }, {
    path: "/login/visitorsOrder",
    component: _53cd0d28,
    name: "login-visitorsOrder"
  }, {
    path: "/settlement/payment",
    component: _b80abcf6,
    name: "settlement-payment"
  }, {
    path: "/settlement/paymentSuccess",
    component: _61aabd6e,
    name: "settlement-paymentSuccess"
  }, {
    path: "/tool/assess",
    component: _01208924,
    name: "tool-assess"
  }, {
    path: "/tool/buyStore",
    component: _7e6e138a,
    name: "tool-buyStore"
  }, {
    path: "/user/aboutUs",
    component: _87f8e6b0,
    name: "user-aboutUs"
  }, {
    path: "/user/auth",
    component: _471cc372,
    name: "user-auth"
  }, {
    path: "/user/bank",
    component: _10fc1133,
    name: "user-bank"
  }, {
    path: "/user/collect",
    component: _2f777172,
    name: "user-collect"
  }, {
    path: "/user/complain",
    component: _78c921c8,
    name: "user-complain"
  }, {
    path: "/user/editPhone",
    component: _d47d9d3e,
    name: "user-editPhone"
  }, {
    path: "/user/info",
    component: _20f6e43e,
    name: "user-info"
  }, {
    path: "/user/message",
    component: _45c32fa4,
    name: "user-message"
  }, {
    path: "/user/my-store",
    component: _832d579a,
    name: "user-my-store"
  }, {
    path: "/user/order",
    component: _ba25ceaa,
    name: "user-order"
  }, {
    path: "/user/seting",
    component: _523cfdb3,
    name: "user-seting"
  }, {
    path: "/user/suggest",
    component: _1ed998a1,
    name: "user-suggest"
  }, {
    path: "/user/auth/bank",
    component: _683d4f57,
    name: "user-auth-bank"
  }, {
    path: "/user/auth/phone",
    component: _6183f63a,
    name: "user-auth-phone"
  }, {
    path: "/user/auth/success",
    component: _29cb31b8,
    name: "user-auth-success"
  }, {
    path: "/user/bank/addBankCard",
    component: _f3332964,
    name: "user-bank-addBankCard"
  }, {
    path: "/user/bank/openBank",
    component: _cbe4e856,
    name: "user-bank-openBank"
  }, {
    path: "/user/order-info/buy",
    component: _7c9c1cf6,
    name: "user-order-info-buy"
  }, {
    path: "/article/:id?",
    component: _4d4d67ac,
    name: "article-id"
  }, {
    path: "/bargain/:key?",
    component: _1b4fdd8c,
    name: "bargain-key"
  }, {
    path: "/order-success/:key?",
    component: _afee25a8,
    name: "order-success-key"
  }, {
    path: "/settlement/:key?",
    component: _06e4e1b1,
    name: "settlement-key"
  }, {
    path: "/si/:key?",
    component: _7094a29e,
    name: "si-key"
  }, {
    path: "/",
    component: _56d55f4c,
    name: "index"
  }, {
    path: "/:store/:id?",
    component: _3e079820,
    name: "store-id"
  }, {
    path: "/article/detail-:id",
    component: _283c73cf,
    name: "detail"
  }, {
    path: "/article/interview-:id",
    component: _6b226073,
    name: "interview"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config.app && config.app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
