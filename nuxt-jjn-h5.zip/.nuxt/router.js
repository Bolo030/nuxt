import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _5cda8940 = () => interopDefault(import('..\\pages\\enter.vue' /* webpackChunkName: "pages/enter" */))
const _196e4632 = () => interopDefault(import('..\\pages\\search\\index.vue' /* webpackChunkName: "pages/search/index" */))
const _7094a29e = () => interopDefault(import('..\\pages\\si\\_key.vue' /* webpackChunkName: "pages/si/_key" */))
const _56d55f4c = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _3e079820 = () => interopDefault(import('..\\pages\\_store\\_id.vue' /* webpackChunkName: "pages/_store/_id" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/enter",
    component: _5cda8940,
    name: "enter"
  }, {
    path: "/search",
    component: _196e4632,
    name: "search"
  }, {
    path: "/si/:key?",
    component: _7094a29e,
    name: "si-key"
  }, {
    path: "/",
    component: _56d55f4c,
    name: "index"
  }, {
    path: "/:store/:id?",
    component: _3e079820,
    name: "store-id"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config.app && config.app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
